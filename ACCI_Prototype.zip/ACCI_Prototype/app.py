import streamlit as st
import pandas as pd
import random

# Load CSVs
kb = pd.read_csv("knowledge.csv")
cases = pd.read_csv("clinical_cases.csv")

st.set_page_config(page_title="ACCI Clinical Prototype", layout="wide")
st.title("ACCI Prototype – Interactive Clinical Learning")
st.write("Professional multi-domain medical cases with feedback dashboard.")

# Inputs
symptoms = st.text_input("Patient symptoms (e.g., fever, jaundice):")

# Generate Patient Case
if "case_text" not in st.session_state:
    st.session_state["case_text"] = ""
if st.button("Generate Case"):
    hits = cases[cases['Symptoms'].apply(lambda x: all(s.strip().lower() in x.lower() for s in symptoms.split(',')))]
    # If no exact match, grab a random case
    if not hits.empty:
        idx = random.choice(hits.index)
        st.session_state["case_text"] = hits.loc[idx, 'Case Description']
        st.session_state["case_subject"] = hits.loc[idx, 'Subject']
    else:
        # Fallback random case
        idx = random.choice(cases.index)
        st.session_state["case_text"] = cases.loc[idx, 'Case Description']
        st.session_state["case_subject"] = cases.loc[idx, 'Subject']

col1, col2 = st.columns(2)
with col1:
    st.subheader("Patient Case")
    st.write(st.session_state["case_text"])

with col2:
    st.subheader("Your Answers & Feedback")
    diagnosis = st.text_input("Diagnosis")
    treatment = st.text_input("Treatment Plan")
    reflection = st.text_area("Reflection: Reason for diagnosis/treatment")

    score = {}
    student_response = (diagnosis + " " + treatment).lower()

    for idx, row in kb.iterrows():
        subject = row['Subject']
        keywords = row['Keywords'].split(';')
        score[subject] = any(kw in student_response for kw in keywords)

    st.write("Feedback per domain:")
    for subject, result in score.items():
        icon = "✅" if result else "❌"
        st.write(f"{icon} {subject}")

# Progress Dashboard (Sidebar)
st.sidebar.header("Progress Dashboard")
completed = sum(score.values())
total = len(kb)
for subject, result in score.items():
    if result:
        st.sidebar.success(f"{subject}: ✅")
    else:
        st.sidebar.error(f"{subject}: ❌")
st.sidebar.progress(completed / total)

# Adaptive Remediation Logic
failed_domains = [sub for sub, ok in score.items() if not ok]
if failed_domains:
    remedial_hits = cases[(cases.Subject == failed_domains[0]) & (cases['Case Description'].str.contains("Remediation"))]
    if not remedial_hits.empty:
        st.subheader(f"Remediation for {failed_domains[0]}")
        st.write(remedial_hits.sample(1)['Case Description'].values[0])
    else:
        st.subheader("Remediation Pending")
        st.write(f"No specific remedial case found for {failed_domains[0]}. Review usual protocols and domain notes.")

# Stress Handling
if len(failed_domains) >= 2:
    st.warning("Multiple knowledge gaps detected. Consider reviewing chapters or consulting a mentor before proceeding.")

# UI polish: Add icons, layout, color, and short explanations as desired

st.info("Demo: Try 2–3 cases, check domain feedback, and see how remediation adapts.")
