
  # Medical Education App Prototype

  This is a code bundle for Medical Education App Prototype. The original project is available at https://www.figma.com/design/HoB7BpTO0rLDRaj3EvEd2m/Medical-Education-App-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  