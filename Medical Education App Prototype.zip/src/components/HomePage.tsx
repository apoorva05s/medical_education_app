import { Button } from "./ui/button";
import { Heart, Brain, Activity } from "lucide-react";

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative h-[600px] overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1731357266501-fc8594f84707?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3R1ZGVudHMlMjBoZWFsdGhjYXJlfGVufDF8fHx8MTc2MDU0MjY5M3ww&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Medical Education"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-blue-700/70"></div>
        </div>
        
        <div className="relative h-full max-w-7xl mx-auto px-6 flex items-center">
          <div className="text-white max-w-2xl">
            <div className="flex items-center gap-2 mb-4">
              <Heart className="w-8 h-8" />
              <span className="text-xl opacity-90">MedLearn Pro</span>
            </div>
            <h1 className="text-5xl mb-6">Transform Your Medical Education Journey</h1>
            <p className="text-xl mb-4 opacity-95">Master clinical skills through AI-powered patient simulations and personalized learning</p>
            <p className="text-lg mb-8 opacity-90">Interactive case studies • Real-time feedback • Adaptive learning paths</p>
            
            <div className="flex gap-4">
              <Button 
                size="lg"
                onClick={() => onNavigate('login')}
                className="bg-white text-blue-700 hover:bg-blue-50"
              >
                Get Started
              </Button>
              <Button 
                size="lg"
                variant="outline"
                onClick={() => onNavigate('login')}
                className="border-white text-white hover:bg-white/10"
              >
                Login
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-card rounded-lg p-8 shadow-sm border border-border">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Brain className="w-6 h-6 text-primary" />
            </div>
            <h3 className="mb-3">AI Patient Role-Play</h3>
            <p className="text-muted-foreground">Practice clinical conversations with realistic AI patients that respond to your diagnostic approach</p>
          </div>
          
          <div className="bg-card rounded-lg p-8 shadow-sm border border-border">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <Activity className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="mb-3">Dynamic Case Generation</h3>
            <p className="text-muted-foreground">Access unlimited patient cases tailored to your learning level and specialty interests</p>
          </div>
          
          <div className="bg-card rounded-lg p-8 shadow-sm border border-border">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <Heart className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="mb-3">Performance Analytics</h3>
            <p className="text-muted-foreground">Track your progress with detailed insights and personalized recommendations</p>
          </div>
        </div>
      </div>
    </div>
  );
}
