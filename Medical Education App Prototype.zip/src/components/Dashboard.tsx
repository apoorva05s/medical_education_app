import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { 
  User, 
  Mail, 
  GraduationCap, 
  Brain, 
  MessageSquare, 
  TrendingUp,
  Activity,
  Heart,
  Dna,
  Pill,
  Stethoscope,
  ClipboardList
} from "lucide-react";
import { useState } from "react";

export function Dashboard() {
  const [chatMessages, setChatMessages] = useState([
    { role: 'ai', content: 'Hello! I am your AI patient. I have been experiencing chest pain for the past 2 hours.' }
  ]);
  const [inputMessage, setInputMessage] = useState('');

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;
    
    setChatMessages([
      ...chatMessages,
      { role: 'user', content: inputMessage },
      { role: 'ai', content: 'The pain is sharp and radiates to my left arm. It started while I was exercising.' }
    ]);
    setInputMessage('');
  };

  const generateCase = () => {
    alert('New patient case generated! A 45-year-old male with acute chest pain and dyspnea.');
  };

  return (
    <div className="p-6 space-y-6">
      {/* Student Details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Student Profile
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-start gap-6">
            <Avatar className="w-20 h-20">
              <AvatarFallback className="bg-primary text-white text-2xl">JD</AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-3">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span>John Doe</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span>john.doe@medschool.edu</span>
                </div>
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-muted-foreground" />
                  <span>Year 3, Internal Medicine</span>
                </div>
                <div className="flex items-center gap-2">
                  <Stethoscope className="w-4 h-4 text-muted-foreground" />
                  <span>124 Cases Completed</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Progress & Stress Indicators */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-600" />
              Learning Progress
            </CardTitle>
            <CardDescription>Your weekly learning goals</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">Cases Completed</span>
                <span className="text-sm">8/10</span>
              </div>
              <Progress value={80} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">Study Hours</span>
                <span className="text-sm">12/15</span>
              </div>
              <Progress value={80} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">Quiz Accuracy</span>
                <span className="text-sm">92%</span>
              </div>
              <Progress value={92} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-orange-600" />
              Wellness Tracker
            </CardTitle>
            <CardDescription>Monitor your stress levels</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">Current Stress Level</span>
              <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                Moderate
              </Badge>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm">Stress Index</span>
                <span className="text-sm">45/100</span>
              </div>
              <Progress value={45} className="h-2" />
            </div>
            <div className="bg-blue-50 rounded-lg p-3 text-sm text-blue-900">
              💡 Tip: Take a 10-minute break every hour to reduce stress
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Patient Case Generator & AI Chat */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ClipboardList className="w-5 h-5" />
              Patient Case Generator
            </CardTitle>
            <CardDescription>Generate new clinical cases to practice</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-muted rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span>Case Type</span>
                <Badge>Cardiology</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>Difficulty</span>
                <Badge variant="outline">Intermediate</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>Duration</span>
                <span className="text-sm text-muted-foreground">20-30 min</span>
              </div>
            </div>
            <Button onClick={generateCase} className="w-full">
              <Brain className="w-4 h-4 mr-2" />
              Generate New Case
            </Button>
            <div className="grid grid-cols-3 gap-2">
              <Button variant="outline" size="sm">Quick Case</Button>
              <Button variant="outline" size="sm">Custom</Button>
              <Button variant="outline" size="sm">Saved</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              AI Patient Role-Play
            </CardTitle>
            <CardDescription>Practice your clinical interview skills</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="h-64 bg-muted rounded-lg p-4 overflow-y-auto space-y-3">
                {chatMessages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        msg.role === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-card border border-border'
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Ask about symptoms..."
                  className="flex-1 px-3 py-2 border border-border rounded-md bg-input-background"
                />
                <Button onClick={handleSendMessage}>Send</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Interactive Visuals */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Dna className="w-5 h-5 text-purple-600" />
              Interactive Anatomy
            </CardTitle>
            <CardDescription>Explore 3D anatomical models</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg flex items-center justify-center border border-border relative overflow-hidden">
              <div className="absolute inset-0 flex items-center justify-center">
                <Heart className="w-32 h-32 text-red-400 opacity-20" />
              </div>
              <div className="relative z-10 text-center space-y-2">
                <Heart className="w-16 h-16 text-red-500 mx-auto" />
                <p className="text-sm text-muted-foreground">Click to explore cardiovascular system</p>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-2 mt-4">
              <Button variant="outline" size="sm">Heart</Button>
              <Button variant="outline" size="sm">Brain</Button>
              <Button variant="outline" size="sm">Lungs</Button>
              <Button variant="outline" size="sm">Kidneys</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Pill className="w-5 h-5 text-blue-600" />
              Drug Interactions
            </CardTitle>
            <CardDescription>Visualize medication interactions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-video bg-gradient-to-br from-blue-50 to-green-50 rounded-lg flex items-center justify-center border border-border relative overflow-hidden">
              <div className="relative space-y-4">
                <div className="flex items-center justify-center gap-4">
                  <div className="w-20 h-20 bg-blue-500 rounded-full flex items-center justify-center text-white shadow-lg">
                    <span className="text-xs">Drug A</span>
                  </div>
                  <div className="w-1 h-1 bg-orange-400 rounded-full animate-pulse"></div>
                  <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center text-white shadow-lg">
                    <span className="text-xs">Drug B</span>
                  </div>
                </div>
                <p className="text-xs text-center text-muted-foreground">Moderate Interaction</p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-4">
              <Button variant="outline" size="sm">Warfarin</Button>
              <Button variant="outline" size="sm">Aspirin</Button>
              <Button variant="outline" size="sm">Statins</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
