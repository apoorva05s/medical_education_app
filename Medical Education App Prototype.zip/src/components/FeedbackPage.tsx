import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { TrendingUp, Award, Target, Lightbulb, BookOpen, Brain } from "lucide-react";

const performanceData = [
  { week: 'Week 1', score: 65 },
  { week: 'Week 2', score: 72 },
  { week: 'Week 3', score: 78 },
  { week: 'Week 4', score: 85 },
  { week: 'Week 5', score: 88 },
  { week: 'Week 6', score: 92 },
];

const categoryData = [
  { category: 'Cardiology', score: 85, cases: 24 },
  { category: 'Neurology', score: 78, cases: 18 },
  { category: 'Respiratory', score: 92, cases: 30 },
  { category: 'Gastro', score: 73, cases: 15 },
  { category: 'Endocrine', score: 88, cases: 22 },
];

const skillsData = [
  { skill: 'Diagnosis', value: 85 },
  { skill: 'Communication', value: 92 },
  { skill: 'Treatment Plan', value: 78 },
  { skill: 'Patient Care', value: 88 },
  { skill: 'Medical Knowledge', value: 82 },
  { skill: 'Critical Thinking', value: 90 },
];

export function FeedbackPage() {
  return (
    <div className="p-6 space-y-6">
      {/* Performance Overview */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Overall Score</CardDescription>
            <CardTitle className="text-3xl">92%</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-green-600">
              <TrendingUp className="w-4 h-4" />
              <span className="text-sm">+8% from last week</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Cases Completed</CardDescription>
            <CardTitle className="text-3xl">124</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-blue-600">
              <Target className="w-4 h-4" />
              <span className="text-sm">Goal: 150</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Avg. Time per Case</CardDescription>
            <CardTitle className="text-3xl">24m</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-purple-600">
              <Award className="w-4 h-4" />
              <span className="text-sm">Efficient!</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Streak</CardDescription>
            <CardTitle className="text-3xl">12d</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 text-orange-600">
              <Award className="w-4 h-4" />
              <span className="text-sm">Keep it up!</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Performance Trend
          </CardTitle>
          <CardDescription>Your scores over the past 6 weeks</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="score" 
                stroke="#0066cc" 
                strokeWidth={3}
                name="Performance Score"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Category Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              Performance by Category
            </CardTitle>
            <CardDescription>Scores across medical specialties</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={categoryData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="category" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Legend />
                <Bar dataKey="score" fill="#0066cc" name="Score %" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Skills Radar */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5" />
              Skills Assessment
            </CardTitle>
            <CardDescription>Your competency across key areas</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={skillsData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="skill" />
                <PolarRadiusAxis domain={[0, 100]} />
                <Radar 
                  name="Skills" 
                  dataKey="value" 
                  stroke="#0066cc" 
                  fill="#0066cc" 
                  fillOpacity={0.5} 
                />
                <Tooltip />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Learning Tips */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-yellow-600" />
            Personalized Learning Tips
          </CardTitle>
          <CardDescription>Recommendations based on your performance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white">1</span>
              </div>
              <div>
                <h4 className="mb-1">Focus on Gastroenterology Cases</h4>
                <p className="text-sm text-muted-foreground">
                  Your gastroenterology score (73%) is below your average. Try completing 5 more cases in this category this week.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white">2</span>
              </div>
              <div>
                <h4 className="mb-1">Excellent Communication Skills!</h4>
                <p className="text-sm text-muted-foreground">
                  Your patient communication score is 92%. Consider mentoring peers or practicing more complex patient interactions.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white">3</span>
              </div>
              <div>
                <h4 className="mb-1">Improve Treatment Planning</h4>
                <p className="text-sm text-muted-foreground">
                  Review evidence-based treatment guidelines. Your treatment plan scores could improve with more systematic approaches.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-white">4</span>
              </div>
              <div>
                <h4 className="mb-1">Study Tip: Spaced Repetition</h4>
                <p className="text-sm text-muted-foreground">
                  Studies show that reviewing cases 24-48 hours after initial completion improves retention by 40%. Try reviewing yesterday's cases!
                </p>
              </div>
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <Badge className="bg-green-100 text-green-800 border-green-200">Strong: Communication</Badge>
            <Badge className="bg-blue-100 text-blue-800 border-blue-200">Strong: Respiratory</Badge>
            <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">Focus: Gastro</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
