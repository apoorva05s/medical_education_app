import { useState } from "react";
import { SidebarProvider, SidebarTrigger } from "./components/ui/sidebar";
import { AppSidebar } from "./components/AppSidebar";
import { HomePage } from "./components/HomePage";
import { LoginPage } from "./components/LoginPage";
import { Dashboard } from "./components/Dashboard";
import { FeedbackPage } from "./components/FeedbackPage";

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  // Pages that don't show the sidebar
  const noSidebarPages = ['home', 'login'];
  const showSidebar = !noSidebarPages.includes(currentPage);

  if (!showSidebar) {
    return (
      <div className="min-h-screen">
        {currentPage === 'home' && <HomePage onNavigate={handleNavigate} />}
        {currentPage === 'login' && <LoginPage onNavigate={handleNavigate} />}
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AppSidebar currentPage={currentPage} onNavigate={handleNavigate} />
        <main className="flex-1">
          <div className="sticky top-0 z-10 bg-background border-b border-border p-4">
            <SidebarTrigger />
          </div>
          {currentPage === 'dashboard' && <Dashboard />}
          {currentPage === 'feedback' && <FeedbackPage />}
        </main>
      </div>
    </SidebarProvider>
  );
}
