import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";
import { Send, User, Bot } from "lucide-react";

interface Message {
  id: number;
  text: string;
  sender: "student" | "patient";
  timestamp: Date;
}

interface PatientChatProps {
  onInteraction: () => void;
}

export function PatientChat({ onInteraction }: PatientChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello, I'm your virtual patient. You can ask me questions about my symptoms, medical history, or request tests. How can I help you today?",
      sender: "patient",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const generatePatientResponse = (studentMessage: string): string => {
    const lowerMessage = studentMessage.toLowerCase();
    
    // Response patterns based on common clinical questions
    if (lowerMessage.includes("pain") || lowerMessage.includes("hurt")) {
      return "The pain is located in my chest, mostly on the left side. It's a sharp, pressing sensation that gets worse when I take deep breaths. It started about 2 hours ago.";
    } else if (lowerMessage.includes("when") || lowerMessage.includes("start")) {
      return "The symptoms started this morning around 8 AM. I was having breakfast when I suddenly felt the chest discomfort and shortness of breath.";
    } else if (lowerMessage.includes("medication") || lowerMessage.includes("drugs") || lowerMessage.includes("taking")) {
      return "I take lisinopril 10mg daily for high blood pressure, and atorvastatin 20mg for cholesterol. I also take aspirin 81mg daily.";
    } else if (lowerMessage.includes("allerg")) {
      return "I'm allergic to penicillin - it gives me a rash. No other known allergies.";
    } else if (lowerMessage.includes("family") || lowerMessage.includes("history")) {
      return "My father had a heart attack at age 55. My mother has diabetes. My brother has high cholesterol as well.";
    } else if (lowerMessage.includes("smoke") || lowerMessage.includes("tobacco")) {
      return "I quit smoking 5 years ago, but I smoked a pack a day for about 15 years before that.";
    } else if (lowerMessage.includes("alcohol") || lowerMessage.includes("drink")) {
      return "I drink socially, maybe 2-3 drinks per week. Nothing excessive.";
    } else if (lowerMessage.includes("exercise") || lowerMessage.includes("active")) {
      return "I've been mostly sedentary lately due to my work schedule. I work at a desk all day.";
    } else if (lowerMessage.includes("test") || lowerMessage.includes("ekg") || lowerMessage.includes("ecg")) {
      return "Sure, I'm ready for any tests you think are necessary. I want to make sure we figure out what's going on.";
    } else if (lowerMessage.includes("blood") || lowerMessage.includes("lab")) {
      return "Yes, you can draw blood for lab work. Should I be concerned about what you're looking for?";
    } else if (lowerMessage.includes("stress") || lowerMessage.includes("anxious")) {
      return "I've been under a lot of stress at work recently. We have a big project deadline coming up. I have been feeling quite anxious about it.";
    } else if (lowerMessage.includes("shortness") || lowerMessage.includes("breath")) {
      return "Yes, I'm having difficulty breathing, especially when I try to move around. I feel like I can't get enough air.";
    } else if (lowerMessage.includes("diagnos") || lowerMessage.includes("think")) {
      return "I'm worried it might be something serious with my heart. That's why I came in today. What do you think, doctor?";
    } else if (lowerMessage.includes("admit") || lowerMessage.includes("hospital")) {
      return "If you think I need to be admitted, I trust your judgment. My health is the priority.";
    } else {
      return "That's a good question. Based on what I'm experiencing - chest pain, shortness of breath, and my history - I think it's important to be thorough. What would you like to know more about?";
    }
  };

  const handleSend = () => {
    if (!inputValue.trim()) return;

    // Add student message
    const studentMessage: Message = {
      id: messages.length + 1,
      text: inputValue,
      sender: "student",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, studentMessage]);
    onInteraction();

    // Generate patient response after a short delay
    setTimeout(() => {
      const patientMessage: Message = {
        id: messages.length + 2,
        text: generatePatientResponse(inputValue),
        sender: "patient",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, patientMessage]);
    }, 800);

    setInputValue("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <Card className="flex flex-col h-[600px]">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bot className="w-5 h-5 text-blue-600" />
          AI Patient Role-Play Chat
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-full px-6" ref={scrollRef}>
          <div className="space-y-4 py-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${
                  message.sender === "student" ? "flex-row-reverse" : "flex-row"
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.sender === "student"
                      ? "bg-blue-600 text-white"
                      : "bg-green-100 text-green-700"
                  }`}
                >
                  {message.sender === "student" ? (
                    <User className="w-4 h-4" />
                  ) : (
                    <Bot className="w-4 h-4" />
                  )}
                </div>
                <div
                  className={`flex-1 max-w-[80%] ${
                    message.sender === "student" ? "text-right" : "text-left"
                  }`}
                >
                  <div
                    className={`inline-block px-4 py-2 rounded-lg ${
                      message.sender === "student"
                        ? "bg-blue-600 text-white"
                        : "bg-secondary text-secondary-foreground"
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {message.timestamp.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter className="border-t pt-4">
        <div className="flex gap-2 w-full">
          <Input
            placeholder="Ask the patient a question or request a test..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1"
          />
          <Button onClick={handleSend} className="bg-blue-600 hover:bg-blue-700">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
