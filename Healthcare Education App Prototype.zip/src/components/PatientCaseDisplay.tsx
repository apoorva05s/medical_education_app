import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Heart, Activity, Thermometer, Droplets } from "lucide-react";

interface PatientCase {
  symptoms: string[];
  vitals: {
    bp: string;
    hr: string;
    temp: string;
    rr: string;
  };
  history: string;
  questions: string[];
  disciplines: string[];
}

interface PatientCaseDisplayProps {
  patientCase: PatientCase | null;
}

export function PatientCaseDisplay({ patientCase }: PatientCaseDisplayProps) {
  if (!patientCase) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-muted-foreground text-center">
            Generate a patient case to begin your clinical simulation
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-600" />
            Chief Complaint & Symptoms
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {patientCase.symptoms.map((symptom, idx) => (
              <Badge key={idx} variant="secondary">
                {symptom}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-600" />
            Vital Signs
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Activity className="w-4 h-4" />
                <span className="text-sm">Blood Pressure</span>
              </div>
              <p>{patientCase.vitals.bp}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Heart className="w-4 h-4" />
                <span className="text-sm">Heart Rate</span>
              </div>
              <p>{patientCase.vitals.hr}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Thermometer className="w-4 h-4" />
                <span className="text-sm">Temperature</span>
              </div>
              <p>{patientCase.vitals.temp}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Droplets className="w-4 h-4" />
                <span className="text-sm">Respiratory Rate</span>
              </div>
              <p>{patientCase.vitals.rr}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Medical History</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">{patientCase.history}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Multi-Disciplinary Involvement</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {patientCase.disciplines.map((discipline, idx) => (
              <Badge key={idx} variant="outline" className="bg-blue-50">
                {discipline}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Clinical Questions to Consider</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {patientCase.questions.map((question, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span className="text-muted-foreground">{question}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
