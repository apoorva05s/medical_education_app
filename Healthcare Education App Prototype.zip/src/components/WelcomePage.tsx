import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Heart, Activity, Stethoscope } from "lucide-react";

interface WelcomePageProps {
  onNavigate: (page: string) => void;
}

export function WelcomePage({ onNavigate }: WelcomePageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 gap-8 items-center mb-16">
          <div className="space-y-6">
            <div className="flex items-center gap-2 mb-4">
              <Stethoscope className="w-8 h-8 text-blue-600" />
              <span className="text-blue-600">ACCI Platform</span>
            </div>
            <h1 className="text-5xl">ACCI Medical Education Prototype</h1>
            <h2 className="text-2xl text-muted-foreground">
              Adaptive Cross-Disciplinary Clinical Integrator
            </h2>
            <p className="text-lg text-muted-foreground">
              Master clinical decision-making through AI-powered patient simulations. 
              Practice multi-system cases, interact with virtual patients, and receive 
              real-time feedback on your clinical reasoning.
            </p>
            <div className="flex gap-4 pt-4">
              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => onNavigate('login')}
              >
                Get Started
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => onNavigate('login')}
              >
                Login
              </Button>
            </div>
          </div>
          <div className="relative h-[500px] rounded-2xl overflow-hidden shadow-2xl">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1504439468489-c8920d796a29?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3R1ZGVudHMlMjBkb2N0b3JzfGVufDF8fHx8MTc2MDUzOTUyMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Medical students and doctors"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Features Section */}
        <div className="grid md:grid-cols-3 gap-8 mt-16">
          <div className="bg-white p-6 rounded-xl shadow-lg border border-border">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Activity className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="mb-2">AI Patient Role-Play</h3>
            <p className="text-muted-foreground">
              Engage with realistic AI patients that respond dynamically to your questions 
              and clinical decisions.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-lg border border-border">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
              <Heart className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="mb-2">Multi-System Cases</h3>
            <p className="text-muted-foreground">
              Practice complex cases involving cardiology, pharmacology, surgery, 
              and other disciplines.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-lg border border-border">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
              <Stethoscope className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="mb-2">Real-Time Feedback</h3>
            <p className="text-muted-foreground">
              Receive instant feedback on your clinical reasoning and performance metrics.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
