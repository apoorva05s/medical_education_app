import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { PatientCaseDisplay } from "./PatientCaseDisplay";
import { PatientChat } from "./PatientChat";
import { 
  User, 
  Calendar, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle,
  Brain,
  Heart,
  Activity
} from "lucide-react";

interface DashboardProps {
  studentName: string;
  studentEmail: string;
}

interface PatientCase {
  symptoms: string[];
  vitals: {
    bp: string;
    hr: string;
    temp: string;
    rr: string;
  };
  history: string;
  questions: string[];
  disciplines: string[];
}

export function Dashboard({ studentName, studentEmail }: DashboardProps) {
  const [symptomInput, setSymptomInput] = useState("");
  const [patientCase, setPatientCase] = useState<PatientCase | null>(null);
  const [progress, setProgress] = useState(45);
  const [stressLevel, setStressLevel] = useState<"Low" | "Medium" | "High">("Low");
  const [interactions, setInteractions] = useState(0);

  const generatePatientCase = () => {
    if (!symptomInput.trim()) return;

    // Mock AI-generated patient case
    const newCase: PatientCase = {
      symptoms: symptomInput.split(",").map(s => s.trim()).filter(s => s),
      vitals: {
        bp: "145/92 mmHg",
        hr: "96 bpm",
        temp: "37.2°C (98.9°F)",
        rr: "20 breaths/min"
      },
      history: "58-year-old male with history of hypertension and hyperlipidemia. Non-smoker for 5 years (previous 15-year history). Works in high-stress environment. Father had MI at age 55. Takes lisinopril 10mg daily and atorvastatin 20mg daily.",
      questions: [
        "What is the differential diagnosis based on the presenting symptoms?",
        "Which diagnostic tests would you order first?",
        "How do the patient's risk factors contribute to the current presentation?",
        "What pharmacological interventions should be considered?",
        "When would you consider specialist consultation or hospital admission?"
      ],
      disciplines: [
        "Cardiology",
        "Internal Medicine",
        "Pharmacology",
        "Emergency Medicine",
        "Radiology"
      ]
    };

    setPatientCase(newCase);
    setSymptomInput("");
    
    // Simulate stress increase with case complexity
    if (stressLevel === "Low") {
      setStressLevel("Medium");
    }
  };

  const handleInteraction = () => {
    setInteractions(prev => prev + 1);
    
    // Update progress based on interactions
    if (progress < 100) {
      setProgress(prev => Math.min(prev + 5, 100));
    }

    // Manage stress level based on performance
    if (interactions > 5 && interactions < 10) {
      setStressLevel("Medium");
    } else if (interactions >= 10) {
      setStressLevel("Low");
    }
  };

  const getStressColor = () => {
    switch (stressLevel) {
      case "Low": return "text-green-600 bg-green-50";
      case "Medium": return "text-yellow-600 bg-yellow-50";
      case "High": return "text-red-600 bg-red-50";
    }
  };

  const lastLogin = new Date().toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header Section */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-4xl mb-2">Student Dashboard</h1>
            <p className="text-muted-foreground">
              Welcome back, continue your clinical training
            </p>
          </div>
          <div className="flex gap-2">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1715111965541-7cdbd8d1aa5b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxodW1hbiUyMGFuYXRvbXklMjBoZWFydHxlbnwxfHx8fDE3NjA1Mzk1MjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Human anatomy"
              className="w-16 h-16 rounded-lg object-cover"
            />
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1676954856957-925f7d2070cc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMG1lZGljYWwlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc2MDUzOTUyMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Medical technology"
              className="w-16 h-16 rounded-lg object-cover"
            />
          </div>
        </div>

        {/* Student Info Cards */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Student Name</p>
                  <p>{studentName}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Progress</p>
                  <p>{progress}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Last Login</p>
                  <p className="text-sm">{lastLogin}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getStressColor()}`}>
                  <Activity className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Stress Level</p>
                  <Badge variant="outline" className={getStressColor()}>
                    {stressLevel}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-blue-600" />
              Visual Integration Mastery Score
            </CardTitle>
            <CardDescription>
              Your clinical reasoning and diagnostic accuracy
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Overall Performance</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
            
            <div className="grid md:grid-cols-3 gap-4 pt-4">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <p className="text-sm">Cases Completed</p>
                  <p className="text-muted-foreground text-sm">12 cases</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Heart className="w-5 h-5 text-red-600 mt-0.5" />
                <div>
                  <p className="text-sm">Diagnostic Accuracy</p>
                  <p className="text-muted-foreground text-sm">87%</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="text-sm">Areas for Improvement</p>
                  <p className="text-muted-foreground text-sm">Pharmacology</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content Tabs */}
        <Tabs defaultValue="case" className="space-y-4">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="case">Patient Case</TabsTrigger>
            <TabsTrigger value="chat">AI Role-Play</TabsTrigger>
          </TabsList>

          <TabsContent value="case" className="space-y-4">
            {/* Generate Case Section */}
            <Card>
              <CardHeader>
                <CardTitle>Generate Patient Case</CardTitle>
                <CardDescription>
                  Enter symptoms to generate an AI-powered multi-system clinical case
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="symptoms">Patient Symptoms (comma-separated)</Label>
                  <Input
                    id="symptoms"
                    placeholder="e.g., chest pain, shortness of breath, fatigue"
                    value={symptomInput}
                    onChange={(e) => setSymptomInput(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === "Enter") {
                        generatePatientCase();
                      }
                    }}
                  />
                </div>
                <Button 
                  onClick={generatePatientCase}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  Generate Case
                </Button>
              </CardContent>
            </Card>

            {/* Patient Case Display */}
            <PatientCaseDisplay patientCase={patientCase} />

            {/* Guidance Tips */}
            {patientCase && (
              <Card className="border-blue-200 bg-blue-50">
                <CardHeader>
                  <CardTitle className="text-blue-900">Clinical Guidance</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-blue-900">
                  <p className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span className="text-sm">Consider the patient's risk factors when formulating your differential diagnosis</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span className="text-sm">Use the AI chat to gather more information before ordering tests</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 mt-1 flex-shrink-0" />
                    <span className="text-sm">Think about drug interactions with current medications</span>
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="chat">
            <PatientChat onInteraction={handleInteraction} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
