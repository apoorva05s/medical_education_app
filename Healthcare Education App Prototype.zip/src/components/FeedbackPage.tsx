import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from "recharts";
import { 
  TrendingUp, 
  Target, 
  Award, 
  AlertCircle, 
  CheckCircle2,
  BookOpen,
  Brain
} from "lucide-react";

export function FeedbackPage() {
  // Mock performance data
  const performanceData = [
    { category: "Cardiology", score: 85 },
    { category: "Pharmacology", score: 72 },
    { category: "Surgery", score: 90 },
    { category: "Internal Med", score: 88 },
    { category: "Emergency", score: 78 },
    { category: "Radiology", score: 82 }
  ];

  const progressOverTime = [
    { week: "Week 1", accuracy: 65, confidence: 60 },
    { week: "Week 2", accuracy: 72, confidence: 68 },
    { week: "Week 3", accuracy: 78, confidence: 75 },
    { week: "Week 4", accuracy: 85, confidence: 82 },
    { week: "Week 5", accuracy: 87, confidence: 85 }
  ];

  const caseDistribution = [
    { name: "Cardiovascular", value: 35, color: "#3b82f6" },
    { name: "Respiratory", value: 25, color: "#10b981" },
    { name: "Neurological", value: 20, color: "#8b5cf6" },
    { name: "Gastrointestinal", value: 20, color: "#f59e0b" }
  ];

  const radarData = [
    { skill: "Diagnosis", current: 85, target: 100 },
    { skill: "Clinical Reasoning", current: 78, target: 100 },
    { skill: "Patient Communication", current: 92, target: 100 },
    { skill: "Treatment Planning", current: 80, target: 100 },
    { skill: "Medical Knowledge", current: 88, target: 100 },
    { skill: "Time Management", current: 75, target: 100 }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-4xl mb-2">Performance Feedback</h1>
          <p className="text-muted-foreground">
            Detailed analytics and recommendations for your clinical training
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Overall Score</p>
                  <p className="text-3xl mt-1">87%</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Award className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Cases Completed</p>
                  <p className="text-3xl mt-1">24</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Response Time</p>
                  <p className="text-3xl mt-1">4.2m</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Target className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Study Streak</p>
                  <p className="text-3xl mt-1">12d</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 1 */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance by Discipline</CardTitle>
              <CardDescription>Your competency across medical specialties</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="category" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="score" fill="#3b82f6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Progress Over Time</CardTitle>
              <CardDescription>Tracking your improvement week by week</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={progressOverTime}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="accuracy" stroke="#3b82f6" strokeWidth={2} />
                  <Line type="monotone" dataKey="confidence" stroke="#10b981" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 2 */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Case Distribution</CardTitle>
              <CardDescription>Types of cases you've practiced</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={caseDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {caseDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Skills Assessment</CardTitle>
              <CardDescription>Your current abilities vs. target performance</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={radarData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="skill" />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} />
                  <Radar name="Current" dataKey="current" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.6} />
                  <Radar name="Target" dataKey="target" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                  <Legend />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Recommendations */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-900">
                <CheckCircle2 className="w-5 h-5" />
                Strengths
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-2">
                <Badge className="bg-green-600 mt-1">Surgery</Badge>
                <p className="text-sm text-green-900">
                  Excellent performance in surgical case management and procedural knowledge
                </p>
              </div>
              <div className="flex items-start gap-2">
                <Badge className="bg-green-600 mt-1">Communication</Badge>
                <p className="text-sm text-green-900">
                  Outstanding patient communication skills and empathetic approach
                </p>
              </div>
              <div className="flex items-start gap-2">
                <Badge className="bg-green-600 mt-1">Internal Medicine</Badge>
                <p className="text-sm text-green-900">
                  Strong diagnostic reasoning in complex multi-system cases
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-900">
                <Brain className="w-5 h-5" />
                Recommended Focus Areas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-2">
                <BookOpen className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-blue-900">
                    <strong>Pharmacology:</strong> Review drug-drug interactions and contraindications
                  </p>
                  <Progress value={72} className="h-1 mt-2" />
                </div>
              </div>
              <div className="flex items-start gap-2">
                <BookOpen className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-blue-900">
                    <strong>Time Management:</strong> Practice faster clinical decision-making
                  </p>
                  <Progress value={75} className="h-1 mt-2" />
                </div>
              </div>
              <div className="flex items-start gap-2">
                <BookOpen className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-blue-900">
                    <strong>Emergency Medicine:</strong> More practice with acute care scenarios
                  </p>
                  <Progress value={78} className="h-1 mt-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Learning Tips */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-blue-600" />
              Personalized Learning Tips
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="border-l-4 border-blue-600 pl-4">
              <h4 className="mb-1">Study Pharmacology Systematically</h4>
              <p className="text-sm text-muted-foreground">
                Focus on drug classes rather than individual medications. Create flashcards for common interactions 
                and side effects. Spend 20 minutes daily reviewing pharmacology concepts.
              </p>
            </div>
            <div className="border-l-4 border-green-600 pl-4">
              <h4 className="mb-1">Practice More Emergency Cases</h4>
              <p className="text-sm text-muted-foreground">
                Try at least 3 emergency medicine cases this week. Focus on rapid assessment and prioritization. 
                Time yourself to improve decision-making speed.
              </p>
            </div>
            <div className="border-l-4 border-purple-600 pl-4">
              <h4 className="mb-1">Build on Your Surgery Strength</h4>
              <p className="text-sm text-muted-foreground">
                You're excelling in surgery! Consider tackling more complex surgical cases or exploring subspecialties 
                like cardiothoracic or neurosurgery.
              </p>
            </div>
            <div className="border-l-4 border-orange-600 pl-4">
              <h4 className="mb-1">Maintain Your Study Streak</h4>
              <p className="text-sm text-muted-foreground">
                Great job maintaining consistency! Try to practice at the same time each day to build a strong habit. 
                Even 15 minutes daily is more effective than longer, irregular sessions.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
