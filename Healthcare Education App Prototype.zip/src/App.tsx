import { useState } from "react";
import { WelcomePage } from "./components/WelcomePage";
import { LoginPage } from "./components/LoginPage";
import { Dashboard } from "./components/Dashboard";
import { FeedbackPage } from "./components/FeedbackPage";
import { Button } from "./components/ui/button";
import { 
  LayoutDashboard, 
  BarChart3, 
  LogOut, 
  Menu,
  X
} from "lucide-react";

type Page = "welcome" | "login" | "dashboard" | "feedback";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("welcome");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [studentName, setStudentName] = useState("");
  const [studentEmail, setStudentEmail] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogin = (name: string, email: string) => {
    setStudentName(name);
    setStudentEmail(email);
    setIsLoggedIn(true);
    setCurrentPage("dashboard");
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setStudentName("");
    setStudentEmail("");
    setCurrentPage("welcome");
    setSidebarOpen(false);
  };

  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
    setSidebarOpen(false);
  };

  // Render sidebar for authenticated users
  const renderSidebar = () => {
    if (!isLoggedIn) return null;

    return (
      <>
        {/* Mobile overlay */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <div
          className={`fixed top-0 left-0 h-full w-64 bg-white border-r border-border z-50 transform transition-transform duration-300 ease-in-out ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          } lg:translate-x-0`}
        >
          <div className="p-6 flex flex-col h-full">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl">ACCI Medical</h2>
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            <nav className="space-y-2 flex-1">
              <Button
                variant={currentPage === "dashboard" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => handleNavigate("dashboard")}
              >
                <LayoutDashboard className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
              <Button
                variant={currentPage === "feedback" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => handleNavigate("feedback")}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Feedback
              </Button>
            </nav>

            <div className="border-t border-border pt-4">
              <div className="mb-4 px-2">
                <p className="text-sm">{studentName}</p>
                <p className="text-xs text-muted-foreground">{studentEmail}</p>
              </div>
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </>
    );
  };

  // Render mobile menu button
  const renderMobileMenuButton = () => {
    if (!isLoggedIn) return null;

    return (
      <Button
        variant="outline"
        size="sm"
        className="fixed top-4 left-4 z-30 lg:hidden"
        onClick={() => setSidebarOpen(true)}
      >
        <Menu className="w-5 h-5" />
      </Button>
    );
  };

  // Render current page
  const renderPage = () => {
    switch (currentPage) {
      case "welcome":
        return <WelcomePage onNavigate={handleNavigate} />;
      case "login":
        return <LoginPage onLogin={handleLogin} onNavigate={handleNavigate} />;
      case "dashboard":
        return <Dashboard studentName={studentName} studentEmail={studentEmail} />;
      case "feedback":
        return <FeedbackPage />;
      default:
        return <WelcomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="size-full flex">
      {renderSidebar()}
      {renderMobileMenuButton()}
      <div className={`flex-1 ${isLoggedIn ? "lg:ml-64" : ""}`}>
        {renderPage()}
      </div>
    </div>
  );
}
