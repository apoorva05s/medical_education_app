
  # Healthcare Education App Prototype

  This is a code bundle for Healthcare Education App Prototype. The original project is available at https://www.figma.com/design/CymTpJ6tOGwLEUgUV0fmcw/Healthcare-Education-App-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  